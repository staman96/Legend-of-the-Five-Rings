#ifndef TypeConverter_h
#define TypeConverter_h

class Personality;
class Holding;
class Item;
class Follower;
class GreenCard;
class BlackCard;

class TypeConverter{

	public:
		// TypeConverter();
		static void getCorrectType(BlackCard *card, Personality *& person, Holding *& hold);
		static void getCorrectType(GreenCard *card, Follower *& follow, Item *& item);
		//Personality *getPersonality(BlackCard *d);
		//Holding *getHolding(BlackCard *d);
		//Follower *getFollower(GreenCard *d);
		//Item *getItem(GreenCard *d);
};

#endif