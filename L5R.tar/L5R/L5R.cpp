#include <bits/stdc++.h>
#include "GameBoard.h"
#include "cards/BlackCards.h"
#include <stdlib.h>


int main(void){
    GameBoard * game = new GameBoard(2);
}