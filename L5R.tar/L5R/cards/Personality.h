#ifndef Personality_h
#define Personality_h

#include <iterator> 
#include <list>
#include <stdlib.h>
#include "Card.h"

using std::list;

class GreenCard;
class BlackCard;

class Personality: public BlackCard{
    protected:
        int attack, defense, honour;
        bool isDead;
        list <GreenCard *> gc;

    public:
        Personality();
        ~Personality();

        /*SETTERS*/
        void setAttack(int);
        void setDefense(int);
        void setHonour(int);
        void setIsdead(bool);

        /*GETTERS*/
        int getAttack();
        int getDefense();
        int getHonour();
        bool getIsdead();
        list <GreenCard *> & getFolItem();
 
        void addcard(GreenCard*);
        int totalATK();
        int totalDEF();
        int totalCards();
        void printGreenCards();
        int sacrificeGreenCard(int index);/*return attack value on success, -1 on error*/
        void printCard() override;
        bool performSeppuku();
        void updateItems();

        int getType() override;
};


#endif