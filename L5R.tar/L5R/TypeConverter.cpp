#include <string>
#include "TypeConverter.h"
#include "cards/Card.h"
#include "cards/Personality.h"
#include "cards/Holding.h"
#include "cards/Follower.h"
#include "cards/Item.h"

enum type{PERSONALITY = 1, HOLDING, FOLLOWER, ITEM};

// TypeConverter::TypeConverter() {}

void TypeConverter::getCorrectType(BlackCard *card, Personality *& person, Holding *& hold)
{
	if (card->getType() == PERSONALITY) {
		//(*person) = getPersonality(card);
		//(pp)=dynamic_cast<Personality*>(pbc);
		(person)=dynamic_cast<Personality*>(card);
		(hold) = NULL;
	}
	else {
		//(*hold) = getHolding(card);
		(hold)=dynamic_cast<Holding*>(card);
		(person) = NULL;
	}
}

void TypeConverter::getCorrectType(GreenCard *card, Follower *& follow, Item *& item)
{
	if (card->getType() == FOLLOWER) {
		//(*follow) = getFollower(card);
		(follow)=dynamic_cast<Follower*>(card);
		(item) = NULL;
	}
	else {
		//(*item) = getItem(card);
		(item)=dynamic_cast<Item*>(card);
		(follow) = NULL;
	}
}

/*Personality *TypeConverter::getPersonality(BlackCard *d)
{
	cout<<"IN PRS"<<endl;
	if (d->getType() == PERSONALITY)
	{
		cout<<"IN IF"<<endl;
		return (Personality *)d;
	}
	return NULL;
}

Holding *TypeConverter::getHolding(BlackCard *d)
{
	if (d->getType() == HOLDING)
		return (Holding *)d;
	return NULL;
}

Follower *TypeConverter::getFollower(GreenCard *d)
{
	if (d->getType() == FOLLOWER)
		return (Follower *)d;
	return NULL;
}

Item *TypeConverter::getItem(GreenCard *d)
{
	if (d->getType() == ITEM)
		return (Item *)d;
	return NULL;
}
*/